library(testthat)
library(formulaic)

test_check("formulaic")
